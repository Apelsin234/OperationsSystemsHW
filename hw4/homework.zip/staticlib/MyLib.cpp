#include "MyLib.h"



char MyLib::returnChar() {
	return '@';
}

int MyLib::sum(int a, int b) {
	return a + b;
}