#pragma once
struct MyLib {

	char returnChar();

	int sum(int a, int b);

};