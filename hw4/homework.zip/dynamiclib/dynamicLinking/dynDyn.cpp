
extern "C" {

int addFour(int a) {
	return a + 4;
}

}