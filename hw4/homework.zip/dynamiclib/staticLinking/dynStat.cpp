#include <iostream> 


void hello() {
	std::cout << "Hello world" << std::endl;
}

double myDiv(double a, double b) {
	return a / b;
}



